package com.anz.SpringBootPractise.employee;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class TopicServices {
	
	private List<Topic> topics = new ArrayList<>(Arrays.asList( new Topic("java","explanation1"),
			new Topic("spring","lool"),
			new Topic("sql","explanation")
			));
	
	public List<Topic> getAllTopics(){
		return topics;
	}
	
	public Topic getTopic(String topicName)
	{
		return topics.stream().filter(e -> e.getTopicName().equals(topicName)).findFirst().get();
	}
	
	public void addTopic(Topic emp)
	{
		topics.add(emp);
	}

	public void updateTopic(String name, Topic topic) {
		Topic upTopic=topics.stream().filter(e -> e.getTopicName().equals(topic)).findFirst().get();
		topics.set(topics.indexOf(upTopic), topic);
	}

	public void deleteTopic(String name) {
		topics.removeIf(e -> e.getTopicName().equals(name));
		
	}

}
