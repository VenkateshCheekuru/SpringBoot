package com.tcs.anz.SpringBoot.Topic;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Topic {
	@Id
	private String topicName;
	private String description;
	
	
	public String getTopicName() {
		return topicName;
	}
	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Topic(String topicName, String description) {
		super();
		this.topicName = topicName;
		this.description = description;
	}
	@Override
	public String toString() {
		return "Topic [topicName=" + topicName + ", description=" + description + "]";
	}
	public Topic() {
		super();
	}
	
	

}
