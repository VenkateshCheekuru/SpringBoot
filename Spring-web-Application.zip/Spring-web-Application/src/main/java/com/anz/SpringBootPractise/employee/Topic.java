package com.anz.SpringBootPractise.employee;

public class Topic {
	private String topicName;
	private String description;

	public Topic() {

	}

	public Topic(String topicName, String description) {
		super();
		this.topicName = topicName;
		this.description = description;

	}

	@Override
	public String toString() {
		return "Topic [topicName=" + topicName + ", description=" + description + "]";
	}

	public String getTopicName() {
		return topicName;
	}

	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
