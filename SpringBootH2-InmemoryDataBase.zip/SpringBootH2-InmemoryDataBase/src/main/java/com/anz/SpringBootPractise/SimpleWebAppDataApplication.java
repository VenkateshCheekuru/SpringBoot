package com.anz.SpringBootPractise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleWebAppDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleWebAppDataApplication.class, args);
	}

}
